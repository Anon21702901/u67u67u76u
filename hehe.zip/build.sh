#!/bin/sh

gcc src/*.c -o android -s -Os -lpthread
